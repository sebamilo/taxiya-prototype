
import { CheckCircle2, Phone, Car, Shield, MapPin, UserPlus, ArrowRight } from "lucide-react";

export default function Page() {
  return (
    <main>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_20%_20%,rgba(99,102,241,0.10),transparent_40%),radial-gradient(circle_at_80%_0%,rgba(147,51,234,0.12),transparent_35%)]"/>
        <div className="max-w-6xl mx-auto px-4 py-16 md:py-24 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-indigo-50 px-3 py-1 text-indigo-700 text-xs font-semibold mb-3">
              <CheckCircle2 className="w-4 h-4"/> Prototipo en desarrollo
            </div>
            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight tracking-tight">
              Pedí <span className="text-indigo-600">tu taxi</span> desde el celular.
            </h1>
            <p className="mt-4 text-slate-600 text-lg">TaxiYa conecta pasajeros con taxis habilitados por el municipio, con tarifas transparentes, seguridad y soporte local.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="/login" className="btn btn-primary"><UserPlus className="w-5 h-5 mr-2"/> Crear cuenta</a>
              <a href="#como-funciona" className="btn btn-ghost">Ver cómo funciona <ArrowRight className="w-4 h-4 ml-1"/></a>
            </div>
          </div>
          <div className="card">
            <div className="card-header flex items-center gap-2"><Phone className="w-5 h-5"/> Demo de Solicitud</div>
            <div className="card-body space-y-3">
              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium">Origen</label>
                  <input className="w-full border rounded-xl px-3 py-2" placeholder="Tu ubicación actual" defaultValue="Cipolletti" />
                </div>
                <div>
                  <label className="block text-sm font-medium">Destino</label>
                  <input className="w-full border rounded-xl px-3 py-2" placeholder="¿A dónde vas?" />
                </div>
                <div>
                  <label className="block text-sm font-medium">Servicio</label>
                  <select className="w-full border rounded-xl px-3 py-2">
                    <option>Estándar</option>
                    <option>Pet-friendly (futuro)</option>
                    <option>VIP (futuro)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium">Hora</label>
                  <select className="w-full border rounded-xl px-3 py-2">
                    <option>Ahora</option>
                    <option>Programar (próximamente)</option>
                  </select>
                </div>
              </div>
              <button className="btn btn-primary w-full"><Car className="w-4 h-4 mr-2"/> Buscar taxi cercano</button>
              <p className="text-xs text-slate-500">*Demo visual. No genera viajes reales aún.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Cómo funciona */}
      <section id="como-funciona" className="py-14 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Cómo funciona</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {[
              {icon: <Phone className="w-5 h-5"/>, title: "Pedí desde la app", desc: "Ingresá origen y destino, elegí el tipo de servicio y confirmá."},
              {icon: <MapPin className="w-5 h-5"/>, title: "Taxi cercano", desc: "Ves el auto en el mapa con datos del chofer y ETA."},
              {icon: <Shield className="w-5 h-5"/>, title: "Viajá seguro", desc: "Tarifa transparente, soporte local y choferes habilitados."},
            ].map((s, i) => (
              <div key={i} className="card">
                <div className="card-header flex items-center gap-2">{s.icon} {s.title}</div>
                <div className="card-body">{s.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Beneficios */}
      <section id="beneficios" className="py-14 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Beneficios para todos</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="card">
              <div className="card-header flex items-center gap-2"><UserPlus className="w-5 h-5"/> Pasajeros</div>
              <div className="card-body space-y-2">
                <p>• Solicitud en 2 toques y seguimiento en tiempo real.</p>
                <p>• Tarifas claras y medios de pago flexibles.</p>
                <p>• Botón de seguridad y soporte local.</p>
              </div>
            </div>
            <div className="card">
              <div className="card-header flex items-center gap-2"><Car className="w-5 h-5"/> Taxistas / Dueños</div>
              <div className="card-body space-y-2">
                <p>• Más viajes y menos tiempo muerto.</p>
                <p>• Panel de estadísticas e ingresos.</p>
                <p>• Integración con normativas municipales.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
