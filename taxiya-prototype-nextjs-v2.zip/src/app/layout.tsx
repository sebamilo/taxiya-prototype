
import type { Metadata } from "next";
import "./globals.css";
import Logo from "@/components/Logo";

export const metadata: Metadata = {
  title: "TaxiYa — Prototipo",
  description: "Landing + Login + Dashboards mock",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>
        <header className="sticky top-0 z-20 backdrop-blur bg-white/70 border-b border-slate-200">
          <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
            <Logo />
            <nav className="flex items-center gap-4 text-sm">
              <a href="#como-funciona" className="hover:text-indigo-600">Cómo funciona</a>
              <a href="#beneficios" className="hover:text-indigo-600">Beneficios</a>
              <a href="/login" className="btn btn-primary">Iniciar sesión</a>
            </nav>
          </div>
        </header>
        {children}
        <footer id="contacto" className="border-t border-slate-200 py-8 mt-12">
          <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <Logo />
            <div className="text-slate-500 text-sm">
              © {new Date().getFullYear()} TaxiYa. Prototipo para validación. Todos los derechos reservados.
            </div>
            <div className="text-sm">
              <a className="hover:text-indigo-600" href="#">Términos</a>
              <span className="mx-2 text-slate-300">•</span>
              <a className="hover:text-indigo-600" href="#">Privacidad</a>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
