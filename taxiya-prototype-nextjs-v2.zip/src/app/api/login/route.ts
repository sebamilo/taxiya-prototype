
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const { role, email } = await req.json();
  if (!role || !email) {
    return NextResponse.json({ error: "Datos inválidos" }, { status: 400 });
  }
  const res = NextResponse.json({ ok: true });
  // Set fake session cookies (httpOnly for realism; in real app use JWT or session store)
  res.cookies.set("taxiya_role", role, { httpOnly: true, path: "/", maxAge: 60 * 60 * 8 });
  res.cookies.set("taxiya_email", email, { httpOnly: true, path: "/", maxAge: 60 * 60 * 8 });
  return res;
}
