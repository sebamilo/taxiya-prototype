
"use client";
import { useState } from "react";
import { LogIn } from "lucide-react";

export default function LoginPage() {
  const [role, setRole] = useState<"pasajero" | "taxista">("pasajero");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role, email })
    });
    if (res.ok) {
      window.location.href = role === "pasajero" ? "/pasajero" : "/taxista";
    } else {
      alert("Error de login (mock).");
    }
  }

  return (
    <main className="max-w-md mx-auto px-4 py-12">
      <div className="card">
        <div className="card-header flex items-center gap-2"><LogIn className="w-5 h-5"/> Acceso a TaxiYa</div>
        <div className="card-body">
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-sm font-medium">Rol</label>
              <div className="flex gap-3 mt-1">
                <button type="button" onClick={() => setRole("pasajero")} className={`px-3 py-1 rounded-xl border ${role==='pasajero' ? 'bg-indigo-600 text-white' : ''}`}>Pasajero/a</button>
                <button type="button" onClick={() => setRole("taxista")} className={`px-3 py-1 rounded-xl border ${role==='taxista' ? 'bg-indigo-600 text-white' : ''}`}>Taxista / Dueño</button>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium">Email o teléfono</label>
              <input className="w-full border rounded-xl px-3 py-2" value={email} onChange={e=>setEmail(e.target.value)} placeholder="tu@email.com / +54..." required />
            </div>
            <div>
              <label className="block text-sm font-medium">Contraseña</label>
              <input type="password" className="w-full border rounded-xl px-3 py-2" value={pass} onChange={e=>setPass(e.target.value)} placeholder="••••••••" required />
            </div>
            <button className="btn btn-primary w-full" type="submit">Ingresar</button>
            <p className="text-xs text-slate-500">*Este login es solo de demostración con cookie de sesión falsa.</p>
          </form>
        </div>
      </div>
    </main>
  );
}
