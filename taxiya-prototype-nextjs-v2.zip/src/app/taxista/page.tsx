
import Link from "next/link";
import { Car } from "lucide-react";

export default function TaxistaPage() {
  return (
    <main className="max-w-6xl mx-auto px-4 py-10">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl md:text-3xl font-bold">Panel de Taxista / Dueño</h1>
        <form action="/api/logout" method="post">
          <button className="btn border" type="submit">Cerrar sesión</button>
        </form>
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        <div className="card">
          <div className="card-header">Estado</div>
          <div className="card-body">
            <p>Sesión activa como <b>taxista</b> (mock).</p>
          </div>
        </div>
        <div className="card">
          <div className="card-header">Próximos pasos</div>
          <div className="card-body space-y-2">
            <p>• Alternar disponibilidad y zona.</p><p>• Ver ingresos estimados.</p><p>• Documentación habilitante.</p>
          </div>
        </div>
        <div className="card">
          <div className="card-header flex items-center gap-2"><Car className="w-5 h-5"/> Demo</div>
          <div className="card-body">
            <p>Este es un tablero de ejemplo. Integraremos datos reales en el MVP.</p>
            <Link className="btn btn-primary mt-3 inline-block" href="/">Volver a la landing</Link>
          </div>
        </div>
      </div>
    </main>
  );
}
