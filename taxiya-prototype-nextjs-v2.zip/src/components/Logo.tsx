
export default function Logo() {
  return (
    <div className="flex items-center gap-2">
      <svg width="28" height="28" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" className="drop-shadow-sm">
        <defs>
          <linearGradient id="grad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#6D28D9" />
            <stop offset="100%" stopColor="#2563EB" />
          </linearGradient>
        </defs>
        <rect x="8" y="8" width="48" height="48" rx="12" fill="url(#grad)"/>
        <path d="M20 38c6-12 18-12 24 0" stroke="white" strokeWidth="4" strokeLinecap="round"/>
        <circle cx="26" cy="42" r="3" fill="white"/>
        <circle cx="38" cy="42" r="3" fill="white"/>
      </svg>
      <span className="text-lg font-extrabold tracking-tight">Taxi<span className="text-indigo-600">Ya</span></span>
    </div>
  );
}
