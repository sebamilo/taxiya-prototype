export default {
  reactStrictMode: true,
  experimental: { serverActions: { allowedOrigins: ['*'] } }
}
